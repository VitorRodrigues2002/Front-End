<template>
    <v-app>
        <div>
            <div class="mars"></div>
                <img src="https://assets.codepen.io/1538474/404.svg" class="logo-404" />
                <img src="https://assets.codepen.io/1538474/meteor.svg" class="meteor" />
                <p class="title">Oh no!!</p>
                <p class="subtitle">
                    You’re either misspelling the URL <br /> or requesting a page that's no longer here.
                </p>
            <div align="center">
                <a class="btn-back" href="/">Back to previous page</a>
            </div>
            <v-img src="https://assets.codepen.io/1538474/astronaut.svg" class="astronaut" />
            <v-img src="https://assets.codepen.io/1538474/spaceship.svg" class="spaceship" />
        </div>
    </v-app>
</template>
 
<style scoped>
@import url('https://fonts.googleapis.com/css?family=Nunito:400,600,700');
 
@mixin breakpoint($point) {
    @if $point==mobile {
        @media (max-width: 480px) and (min-width: 320px) {
            @content ;
        }
    }
}
 
@keyframes floating {
    from { transform: translateY(0px); }
    65%  { transform: translateY(15px); }
    to   { transform: translateY(-0px); }
}
 
html {
  height: 100%;
}
 
body{
  background-image: url('https://assets.codepen.io/1538474/star.svg'),linear-gradient(to bottom, #05007A, #4D007D);
  height: 100%;
  margin: 0;
  background-attachment: fixed;
  overflow: hidden;
}
 
.mars{
  left:0;
  right:0;
  bottom:0;
  position:absolute;
  height: 27vmin;
  background: url('https://assets.codepen.io/1538474/mars.svg') no-repeat bottom center; /*  footer  */
  background-size: cover;
}
 
.logo-404{
  position: absolute;
  margin-left: auto;
  margin-right: auto;
  left: 0;
  right: 0;
  top: 16vmin;
  width: 30vmin;
 
}
 
.meteor{
  position: absolute;
  right: 2vmin;
  top: 16vmin;
}
 
.title{
  color: rgb(255, 114, 55);
  font-weight: 600;
  text-align: center;
  font-size: 5vmin;
  margin-top: 31vmin;
 
}
 
.subtitle{
  color: rgb(255, 114, 55);
  font-weight: 400;
  text-align: center;
  font-size: 3.5vmin;
  margin-top: -1vmin;
  margin-bottom: 9vmin;
}
 
.btn-back{
  border: 1px solid orange;
  color: orange;
  height: 5vmin;
  padding: 12px;
  text-decoration: none;
  border-radius: 5px;
 
}
 
.btn-back.hover{
    background: white;
    color: #4D007D;
  }
.astronaut{
  position: absolute;
  top: 18vmin;
  left: 10vmin;
  height: 30vmin;
    animation: floating 3s infinite ease-in-out;
 
}
 
.spaceship{
  position: absolute;
  bottom: 15vmin;
  right: 24vmin;
 
}
</style>